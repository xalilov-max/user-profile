from django.shortcuts import render, get_object_or_404
from .models import Profile, Comment
from django.contrib.auth.models import User

def profile_view(request, username):
    user = get_object_or_404(User, username=username)
    profile = Profile.objects.get(user=user)
    comments = Comment.objects.filter(user=user)
    return render(request, 'profiles/profile.html', {'profile': profile, 'comments': comments})
